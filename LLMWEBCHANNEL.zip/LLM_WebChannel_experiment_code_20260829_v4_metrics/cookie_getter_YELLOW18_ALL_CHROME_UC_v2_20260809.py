#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime
from pathlib import Path

from seleniumbase import SB

HERE = Path(__file__).resolve().parent
DEFAULT_COOKIE_DIR = HERE / "cookies"

AI_PRESETS = {
    "doubao": ("豆包", "https://www.doubao.com/chat/"),
    "metaso": ("秘塔 AI 搜索", "https://metaso.cn/"),
    "yuanbao": ("腾讯元宝", "https://yuanbao.tencent.com/"),
    "wenxin": ("百度文心一言", "https://yiyan.baidu.com/"),
    "qianwen": ("通义千问", "https://www.qianwen.com/"),
    "zhipu": ("智谱清言", "https://chatglm.cn/"),
    "nami": ("纳米 AI", "https://bot.n.cn/"),
    "shanhai": ("山海大模型", "https://shanhai.unisound.com/"),
    "internai": ("书生·浦语", "https://chat.intern-ai.org.cn/"),
    "chatgpt": ("ChatGPT", "https://chatgpt.com/"),
    "perplexity": ("Perplexity", "https://www.perplexity.ai/"),
    "mistral": ("Mistral", "https://chat.mistral.ai/"),
    "grok": ("Grok", "https://grok.com/"),
    "huggingchat": ("HuggingChat", "https://huggingface.co/chat/"),
    "dola": ("Dola（豆包国际版）", "https://www.dola.com/chat/"),
    "qwen_global": ("Qwen Chat 国际版", "https://chat.qwen.ai/"),
    "coze": ("扣子 Coze", "https://www.coze.cn/"),
    "stepfun": ("阶跃 AI", "https://chat.stepfun.com/"),
}


def select_ais(raw: str | None) -> list[str]:
    names = list(AI_PRESETS)
    if not raw:
        print("\n黄色18个平台（全部 Chrome + UC）：")
        for i, name in enumerate(names, 1):
            label, url = AI_PRESETS[name]
            print(f"{i:>2}. {name:<12} {label:<16} {url}")
        raw = input("\n输入编号/名称，多个逗号分隔，全部输入 all：").strip()
    if raw.lower() in {"all", "全部", "*"}:
        return names
    selected: list[str] = []
    for token in raw.replace("，", ",").split(","):
        token = token.strip()
        if not token:
            continue
        if token.isdigit():
            idx = int(token)
            if not 1 <= idx <= len(names):
                raise ValueError(f"编号不存在：{token}")
            name = names[idx - 1]
        else:
            name = token.lower()
            if name not in AI_PRESETS:
                raise ValueError(f"平台不存在：{token}")
        if name not in selected:
            selected.append(name)
    if not selected:
        raise ValueError("没有选择平台")
    return selected


def normalize_cookie_for_selenium(cookie: dict) -> dict | None:
    """只保留 Selenium add_cookie() 能稳定回写的字段。"""
    name = cookie.get("name")
    value = cookie.get("value")
    if not isinstance(name, str) or not isinstance(value, str):
        return None
    out = {"name": name, "value": value}
    for key in ("domain", "path"):
        v = cookie.get(key)
        if isinstance(v, str) and v:
            out[key] = v
    for key in ("secure", "httpOnly"):
        v = cookie.get(key)
        if isinstance(v, bool):
            out[key] = v
    same_site = cookie.get("sameSite")
    if same_site in {"Strict", "Lax", "None"}:
        out["sameSite"] = same_site
    expiry = cookie.get("expiry")
    if isinstance(expiry, (int, float)) and not isinstance(expiry, bool) and expiry > 0:
        out["expiry"] = int(expiry)
    return out


def save_current_domain_cookies(driver, ai: str, cookie_dir: Path) -> Path:
    raw = driver.get_cookies()
    cookies = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        normalized = normalize_cookie_for_selenium(item)
        if normalized:
            cookies.append(normalized)

    cookie_dir.mkdir(parents=True, exist_ok=True)
    path = cookie_dir / f"{ai}.json"
    path.write_text(json.dumps(cookies, ensure_ascii=False, indent=2), encoding="utf-8")

    meta = {
        "ai": ai,
        "captured_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "current_url": driver.current_url,
        "cookie_count": len(cookies),
        "browser": "Chrome+UC",
        "cookie_file": str(path),
        "cookie_names": [c.get("name", "") for c in cookies],
    }
    (cookie_dir / f"{ai}.meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="黄色18平台 Cookie 获取器：18个平台统一使用本机 Chrome + SeleniumBase UC Mode"
    )
    parser.add_argument("--ais", default="", help="例如 chatgpt,doubao 或 all")
    parser.add_argument("--cookie-dir", default=str(DEFAULT_COOKIE_DIR))
    parser.add_argument(
        "--post-enter-wait",
        type=float,
        default=2.0,
        help="你按回车确认登录完成后，再等待多少秒保存 Cookie，默认2秒",
    )
    args = parser.parse_args()

    selected = select_ais(args.ais or None)
    cookie_dir = Path(args.cookie_dir).expanduser().resolve()

    print("\n浏览器策略：黄色18个平台全部统一使用 Chrome + UC。")
    print(f"Cookie 输出目录：{cookie_dir}")

    for index, ai in enumerate(selected, 1):
        label, url = AI_PRESETS[ai]
        print("\n" + "=" * 72)
        print(f"[{index}/{len(selected)}] {ai} / {label}")
        print(f"打开：{url}")

        # 每个平台单独启动一个 Chrome+UC，避免跨平台 Cookie/Storage 相互干扰。
        with SB(browser="chrome", headless=False, uc=True) as sb:
            driver = sb.driver
            driver.get(url)
            print(
                f"[{ai}] 请在打开的 Chrome 中完成登录，并进入后续实验实际使用的页面。\n"
                "完成后回到终端按 Enter；程序只在你按 Enter 后保存当前页面域可见 Cookie。"
            )
            input(f"[{ai}] 登录完成后按 Enter 保存 Cookie > ")
            time.sleep(max(0.0, float(args.post_enter_wait)))

            path = save_current_domain_cookies(driver, ai, cookie_dir)
            count = len(json.loads(path.read_text(encoding="utf-8")))
            print(f"[{ai}] 已保存 {count} 条 Cookie：{path}")
            if count == 0:
                print(f"[{ai}] 警告：当前页面没有读取到 Cookie，请检查是否已登录/是否位于正确域名。")

    print("\n全部选定平台处理完成。Cookie 文件名与实验程序要求一致：cookies/<ai>.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
