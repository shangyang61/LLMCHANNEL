#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Redact experiment logs and create a public metadata export.

将 CSV/JSONL 审计日志导出为公开版本。敏感字段、Cookie、认证、正文、
原始 URL、IP、邮箱、路径、令牌与文件内容均被删除或替换。
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from pathlib import Path
from typing import Any

SENSITIVE_KEY = re.compile(r"cookie|auth|token|password|secret|credential|payload(?!_bytes|_sha256)|content|body|html|header|request|response|url|path|account|email|ip", re.I)
EMAIL = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
IPV4 = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
BEARER = re.compile(r"(?i)bearer\s+[A-Za-z0-9._~+/-]{8,}")
WINDOWS_PATH = re.compile(r"(?i)(?:[A-Z]:\\|/)[^\s\"']+")


def scrub_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): "[REDACTED]" if SENSITIVE_KEY.search(str(k)) else scrub_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [scrub_value(v) for v in value]
    if not isinstance(value, str):
        return value
    value = BEARER.sub("[AUTH_REDACTED]", value)
    value = EMAIL.sub("[EMAIL_REDACTED]", value)
    value = IPV4.sub("[IP_REDACTED]", value)
    return WINDOWS_PATH.sub("[PATH_REDACTED]", value)


def load_rows(path: Path) -> list[dict[str, Any]]:
    if path.suffix.lower() == ".jsonl":
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            return list(csv.DictReader(handle))
    raise ValueError("Only .csv and .jsonl are supported / 仅支持 .csv 与 .jsonl")


def main() -> int:
    parser = argparse.ArgumentParser(description="Sanitized public export / 脱敏公开数据导出")
    parser.add_argument("--input", action="append", required=True, help="CSV or JSONL audit file; repeatable / CSV 或 JSONL 审计文件，可重复传入")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    root = Path(args.output_dir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    manifest = []
    for index, raw_path in enumerate(args.input, 1):
        source = Path(raw_path).expanduser().resolve()
        rows = [scrub_value(row) for row in load_rows(source)]
        output = root / f"public_audit_{index:02d}.jsonl"
        with output.open("w", encoding="utf-8") as handle:
            for row in rows:
                handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        manifest.append({"source_id": hashlib.sha256(source.name.encode()).hexdigest()[:16], "row_count": len(rows), "public_file": output.name})
        print(f"[EXPORT] {len(rows)} rows exported / 已导出 {len(rows)} 行：{output}")
    (root / "public_export_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
