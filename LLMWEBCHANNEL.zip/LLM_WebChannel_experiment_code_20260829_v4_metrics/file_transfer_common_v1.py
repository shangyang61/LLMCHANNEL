#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared, privacy-preserving helpers for authorized file-transfer measurements.

公共、隐私保护的文件传输实验工具。该模块只记录试验元数据、计时和
SHA-256；不会读取或保存 Cookie、账号、网页正文、文件内容或完整本地路径。
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utc_now() -> str:
    """Return an unambiguous audit timestamp / 返回审计用 UTC 时间。"""
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def safe_id(value: str) -> str:
    """Make a filesystem-safe identifier / 生成安全文件名标识。"""
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", value.strip())
    return cleaned.strip("._") or "run"


def sha256_file(path: Path) -> str:
    """Hash a file without logging its bytes / 计算哈希但不记录文件内容。"""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def synthetic_payload(path: Path, size_bytes: int, trial_id: str) -> dict[str, Any]:
    """Create deterministic synthetic bytes, never from a user file.

    创建确定性的合成测试文件，绝不读取用户文件作为测试载荷。
    """
    if size_bytes < 1:
        raise ValueError("size_bytes must be >= 1 / 文件大小必须至少为 1 字节")
    header = (f"LLM-WEBCHANNEL-AUTHORIZED-FILE-TRIAL:{trial_id}\n").encode("ascii")
    stream = bytearray()
    counter = 0
    while len(stream) < size_bytes:
        stream.extend(hashlib.sha256(header + counter.to_bytes(8, "big")).digest())
        counter += 1
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(bytes(stream[:size_bytes]))
    return {
        "filename": path.name,
        "payload_bytes": size_bytes,
        "payload_sha256": sha256_file(path),
    }


@dataclass
class TrialRecord:
    """Minimal audit record / 最小化审计记录。"""
    trial_id: str
    carrier: str
    platform_label: str
    mode: str
    started_utc: str
    ended_utc: str
    elapsed_s: float
    status: str
    filename: str
    payload_bytes: int
    payload_sha256: str
    observed_sha256: str = ""
    selector_used: str = ""
    note: str = ""
    manual_started_utc: str = ""
    automatic_started_utc: str = ""
    automatic_ended_utc: str = ""
    manual_ended_utc: str = ""
    manual_elapsed_s: float = 0.0
    automatic_elapsed_s: float = 0.0


class AuditWriter:
    """Write JSONL and CSV without sensitive browser data / 写入不含敏感浏览器数据的日志。"""

    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.jsonl_path = self.output_dir / "file_transfer_audit.jsonl"
        self.csv_path = self.output_dir / "file_transfer_audit.csv"

    def append(self, record: TrialRecord) -> None:
        row = asdict(record)
        with self.jsonl_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        new_file = not self.csv_path.exists()
        with self.csv_path.open("a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(row))
            if new_file:
                writer.writeheader()
            writer.writerow(row)


class ManifestWriter:
    """Append and resolve trial manifests / 写入并读取逐次试验 manifest。"""

    def __init__(self, manifest_path: Path) -> None:
        self.manifest_path = manifest_path
        self.manifest_path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, row: dict[str, Any]) -> None:
        with self.manifest_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

    @staticmethod
    def resolve(manifest_path: Path, trial_id: str) -> dict[str, Any]:
        if not manifest_path.is_file():
            raise FileNotFoundError(f"Manifest not found / 未找到 manifest：{manifest_path}")
        matched: dict[str, Any] | None = None
        for raw in manifest_path.read_text(encoding="utf-8").splitlines():
            if not raw.strip():
                continue
            row = json.loads(raw)
            if row.get("trial_id") == trial_id:
                matched = row
        if matched is None:
            raise KeyError(f"trial_id not found / manifest 中没有 trial_id：{trial_id}")
        return matched


def prompt_gate(prompt: str) -> float:
    """Manual time gate: Enter marks the timing edge / 回车即人工计时边界。"""
    input(prompt)
    return time.perf_counter()


def public_dom_probe(driver: Any) -> list[dict[str, Any]]:
    """Return safe control metadata only, never DOM text, values, URLs, or HTML.

    仅返回控件的安全元数据；不返回页面文本、输入值、URL、HTML 或 Cookie。
    """
    script = r"""
    const out=[];
    const selectors=['input[type="file"]','button','[role="button"]','a[download]'];
    const seen=new Set();
    for(const selector of selectors){
      for(const el of document.querySelectorAll(selector)){
        if(seen.has(el)) continue; seen.add(el);
        const rect=el.getBoundingClientRect();
        out.push({
          selector_hint: selector,
          tag: (el.tagName||'').toLowerCase(),
          type: el.getAttribute('type')||'',
          role: el.getAttribute('role')||'',
          aria_label: (el.getAttribute('aria-label')||'').slice(0,120),
          title: (el.getAttribute('title')||'').slice(0,120),
          accept: (el.getAttribute('accept')||'').slice(0,120),
          enabled: !el.disabled,
          visible: !!(rect.width||rect.height),
        });
      }
    }
    return out.slice(0,200);
    """
    result = driver.execute_script(script)
    return result if isinstance(result, list) else []


def print_dom_probe(controls: list[dict[str, Any]]) -> None:
    """Human-readable bilingual locator report / 双语定位报告。"""
    print("\n[DOM] Safe control probe / 安全控件探测：")
    if not controls:
        print("[DOM] No standard upload/download controls found / 未发现标准上传或下载控件。")
        return
    for i, item in enumerate(controls, 1):
        print(
            f"[DOM] {i:02d}. {item.get('selector_hint')} tag={item.get('tag')} "
            f"type={item.get('type')} role={item.get('role')} "
            f"aria={item.get('aria_label')!r} accept={item.get('accept')!r} "
            f"visible={item.get('visible')} enabled={item.get('enabled')}"
        )
