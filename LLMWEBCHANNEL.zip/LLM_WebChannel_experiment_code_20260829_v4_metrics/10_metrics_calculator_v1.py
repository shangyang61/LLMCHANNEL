#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compute auditable LLM-WebChannel metrics from per-trial CSV/JSONL logs.

统一计算 RSR、USR、URR、发送/接收/端点速率、Wilson 95% 置信区间和失败分类。
输入必须是逐次试验记录；输出不包含 payload 或页面内容，只保留 trial_id 数据血缘。
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


TRUE = {"1", "true", "yes", "y", "success", "completed", "complete", "matched"}
FALSE = {"0", "false", "no", "n", "failed", "failure", "timeout", "rejected", "unsupported"}


def load_rows(path: Path) -> list[dict[str, Any]]:
    """Load audit rows / 读取逐次审计记录。"""
    if path.suffix.lower() == ".jsonl":
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            return list(csv.DictReader(handle))
    raise ValueError("Input must be .jsonl or .csv / 输入必须为 .jsonl 或 .csv")


def first(row: dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        value = row.get(key)
        if value not in (None, ""):
            return value
    return default


def as_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None or value == "":
        return None
    text = str(value).strip().lower()
    if text in TRUE:
        return True
    if text in FALSE:
        return False
    return None


def as_float(value: Any) -> float | None:
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (TypeError, ValueError):
        return None


def timestamp(value: Any) -> float | None:
    """Accept numeric seconds or ISO-8601 timestamps / 接受秒数或 ISO 时间戳。"""
    number = as_float(value)
    if number is not None:
        return number
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def duration(row: dict[str, Any], duration_keys: tuple[str, ...], start_keys: tuple[str, ...], end_keys: tuple[str, ...]) -> float | None:
    direct = as_float(first(row, *duration_keys))
    if direct is not None and direct > 0:
        return direct
    start, end = timestamp(first(row, *start_keys)), timestamp(first(row, *end_keys))
    if start is not None and end is not None and end > start:
        return end - start
    return None


def wilson(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float | None, float | None]:
    if total <= 0:
        return None, None
    p = successes / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    half = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denom
    return max(0.0, center - half), min(1.0, center + half)


def median(values: list[float]) -> float | None:
    return statistics.median(values) if values else None


def rate(payload_bytes: float | None, seconds: float | None) -> float | None:
    if payload_bytes is None or seconds is None or seconds <= 0:
        return None
    return payload_bytes / 1024.0 / seconds  # KiB/s; logical payload only.


def trial_metrics(row: dict[str, Any], index: int) -> dict[str, Any]:
    """Normalize aliases into one paper-aligned trial record / 统一字段别名。"""
    carrier = str(first(row, "carrier", "mode", default="")).strip().lower()
    platform = str(first(row, "platform_label", "platform", "service", "ai", default="unknown")).strip()
    trial_id = str(first(row, "trial_id", "run_id", "id", default=f"row-{index:06d}"))
    payload = as_float(first(row, "payload_bytes", "logical_payload_bytes", "bytes", "data_bytes"))
    status = str(first(row, "status", "outcome", default="unknown")).strip().lower()

    normalized = as_bool(first(row, "normalized_content_consistent", "content_consistent", "recovery_success", "success"))
    submitted = as_bool(first(row, "submission_success", "url_submission_success", "usr_success"))
    endpoint_match = as_bool(first(row, "endpoint_payload_match", "endpoint_match", "url_endpoint_match", "urr_success"))
    if carrier in {"text", "file"} and normalized is None:
        normalized = status in {"success", "completed", "manual_complete", "download_detected"}
    if carrier == "url" and submitted is None:
        submitted = status in {"success", "completed", "submitted", "endpoint_match"}
    if carrier == "url" and endpoint_match is None:
        endpoint_match = status in {"success", "endpoint_match"}

    sender_seconds = duration(row, ("sender_elapsed_s", "send_elapsed_s", "manual_elapsed_s"),
                              ("sender_started_utc", "send_started_utc", "t_send_start", "t_submit_start"),
                              ("sender_ended_utc", "send_ended_utc", "t_send_done", "t_submit_end"))
    receiver_seconds = duration(row, ("receiver_elapsed_s", "receive_elapsed_s", "recovery_elapsed_s"),
                                ("receiver_started_utc", "recovery_started_utc", "t_recv_start"),
                                ("receiver_ended_utc", "recovery_ended_utc", "t_recv_done"))
    endpoint_seconds = duration(row, ("endpoint_elapsed_s", "url_endpoint_elapsed_s"),
                                ("url_submit_utc", "t_sub", "submission_ended_utc", "t_submit_end"),
                                ("endpoint_received_utc", "t_srv", "endpoint_ended_utc"))
    return {
        "trial_id": trial_id, "platform": platform, "carrier": carrier, "status": status,
        "payload_bytes": payload, "recovery_success": normalized,
        "submission_success": submitted, "endpoint_match": endpoint_match,
        "sender_rate_kib_s": rate(payload, sender_seconds),
        "receiver_rate_kib_s": rate(payload, receiver_seconds),
        "endpoint_rate_kib_s": rate(payload, endpoint_seconds),
    }


def summarize(group: list[dict[str, Any]]) -> dict[str, Any]:
    carrier = group[0]["carrier"]
    recovery = [x["recovery_success"] for x in group if x["recovery_success"] is not None]
    submit = [x["submission_success"] for x in group if x["submission_success"] is not None]
    joint = [bool(x["submission_success"] and x["endpoint_match"]) for x in group if x["submission_success"] is not None and x["endpoint_match"] is not None]
    def metric(values: list[bool], label: str) -> dict[str, Any]:
        numerator, denominator = sum(values), len(values)
        lo, hi = wilson(numerator, denominator)
        return {f"{label}_successes": numerator, f"{label}_n": denominator, f"{label}": numerator / denominator if denominator else None, f"{label}_ci95_low": lo, f"{label}_ci95_high": hi}
    result: dict[str, Any] = {
        "platform": group[0]["platform"], "carrier": carrier, "trial_count": len(group),
        "sender_rate_median_kib_s": median([x["sender_rate_kib_s"] for x in group if x["sender_rate_kib_s"] is not None]),
        "receiver_rate_median_kib_s": median([x["receiver_rate_kib_s"] for x in group if x["receiver_rate_kib_s"] is not None]),
        "endpoint_rate_median_kib_s": median([x["endpoint_rate_kib_s"] for x in group if x["endpoint_rate_kib_s"] is not None]),
        "failure_counts": dict(Counter(x["status"] for x in group if x["status"] not in {"success", "completed", "endpoint_match", "submitted"})),
        "trial_ids": [x["trial_id"] for x in group],
    }
    if carrier in {"text", "file"}:
        result.update(metric(recovery, "RSR"))
    if carrier == "url":
        result.update(metric(submit, "USR"))
        result.update(metric(joint, "URR"))  # joint browser submission plus endpoint payload match.
    return result


def write_csv(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    rows = list(rows)
    fields = sorted({key for row in rows for key in row if key != "trial_ids"})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: value for key, value in row.items() if key != "trial_ids"})


def main() -> int:
    parser = argparse.ArgumentParser(description="LLM-WebChannel metrics calculator / 统一指标计算器")
    parser.add_argument("--input", action="append", required=True, help="Per-trial .csv or .jsonl; repeatable / 逐次记录，可重复传入")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    output = Path(args.output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    raw = [row for item in args.input for row in load_rows(Path(item).expanduser())]
    trials = [trial_metrics(row, index + 1) for index, row in enumerate(raw)]
    groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for trial in trials:
        if trial["carrier"] in {"text", "file", "url"}:
            groups[(trial["platform"], trial["carrier"])].append(trial)
    summaries = [summarize(rows) for _, rows in sorted(groups.items())]
    (output / "metrics_summary.json").write_text(json.dumps(summaries, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(output / "metrics_by_platform_carrier.csv", summaries)
    with (output / "metric_cell_lineage.jsonl").open("w", encoding="utf-8") as handle:
        for row in summaries:
            handle.write(json.dumps({"platform": row["platform"], "carrier": row["carrier"], "trial_ids": row["trial_ids"]}, ensure_ascii=False) + "\n")
    print(f"[DONE] {len(trials)} trials, {len(summaries)} platform-carrier cells / 已计算 {len(trials)} 次试验、{len(summaries)} 个平台-载体单元。")
    print(f"[OUTPUT] {output} / 输出目录：{output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
