#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Authorized file-upload measurement with manual and automatic timing.

仅用于自有或明确授权的账户与服务。此脚本不读取 Cookie、不自动登录，
不保存网页内容、账号、完整路径或文件正文。
"""
from __future__ import annotations

import argparse
import time
import uuid
from pathlib import Path
from typing import Any

from file_transfer_common_v1 import (
    AuditWriter, ManifestWriter, TrialRecord, print_dom_probe, public_dom_probe, prompt_gate,
    safe_id, synthetic_payload, utc_now,
)


def choose_file_input(driver: Any, css_selector: str) -> tuple[Any, str]:
    """Locate a standard file input / 定位标准 file input 控件。"""
    selector = css_selector.strip() or 'input[type="file"]'
    elements = driver.find_elements("css selector", selector)
    if not elements:
        raise RuntimeError(
            f"No file input matched {selector!r}. Run --probe first and supply "
            "--file-selector / 未找到上传控件，请先使用 --probe 后传入 --file-selector。"
        )
    return elements[0], selector


def wait_for_completion(driver: Any, selector: str, timeout_s: float) -> bool:
    """Wait for an explicitly supplied completion signal / 等待显式提供的完成信号。"""
    deadline = time.perf_counter() + timeout_s
    while time.perf_counter() < deadline:
        try:
            element = driver.find_elements("css selector", selector)[0]
            if element.is_displayed():
                return True
        except Exception:
            pass
        time.sleep(0.25)
    return False


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Authorized file upload / 授权文件上传：manual and automatic timing / 人工和自动计时"
    )
    parser.add_argument("--url", required=True, help="Service page URL / 服务页面地址")
    parser.add_argument("--platform", default="service", help="Neutral label only / 仅中性标签")
    parser.add_argument("--bytes", type=int, default=4096, help="Synthetic payload size / 合成载荷大小")
    parser.add_argument("--file-selector", default='', help="CSS selector for the input[type=file] / 上传控件 CSS 选择器")
    parser.add_argument("--completion-selector", default='', help="Visible completion signal selector / 可见完成信号的选择器")
    parser.add_argument("--submit-selector", default='', help="Optional upload/submit control selector / 可选上传或提交控件选择器")
    parser.add_argument("--auto-action", action="store_true", help="Allow the script to click --submit-selector / 允许脚本点击 --submit-selector")
    parser.add_argument("--run-id", default='', help="Cross-carrier run ID / 跨载体试验轮次 ID")
    parser.add_argument("--trial-id", default='', help="Stable trial ID / 固定的单次试验 ID")
    parser.add_argument("--manifest", default='', help="Manifest JSONL path / manifest JSONL 路径")
    parser.add_argument("--timeout", type=float, default=90.0)
    parser.add_argument("--output-dir", default="file_upload_results")
    parser.add_argument("--probe", action="store_true", help="Inspect safe control metadata then exit / 仅探测控件后退出")
    parser.add_argument("--authorized", action="store_true", help="Required acknowledgement / 必须确认拥有授权")
    args = parser.parse_args()
    if not args.authorized:
        raise SystemExit("Refusing to run: pass --authorized only for your authorized account/service. / 请仅在授权服务上添加 --authorized。")
    if not 1 <= args.bytes <= 1024 * 1024:
        raise SystemExit("--bytes must be 1..1048576 / --bytes 必须在 1 到 1048576 之间")

    try:
        from seleniumbase import SB  # type: ignore
    except ImportError as exc:
        raise SystemExit("Missing SeleniumBase / 缺少 SeleniumBase：python -m pip install -U seleniumbase") from exc

    run_id = safe_id(args.run_id or f"file-upload-{args.platform}-{uuid.uuid4().hex[:8]}")
    trial_id = safe_id(args.trial_id or f"{run_id}-t001")
    out_dir = Path(args.output_dir).expanduser().resolve() / run_id
    payload_path = out_dir / "synthetic_payload.bin"
    audit = AuditWriter(out_dir)
    manifest_path = Path(args.manifest).expanduser().resolve() if args.manifest else out_dir / "file_trial_manifest.jsonl"
    manifest = ManifestWriter(manifest_path)
    meta = synthetic_payload(payload_path, args.bytes, trial_id)
    manifest.append({
        "record_type": "file_upload_plan", "run_id": run_id, "trial_id": trial_id,
        "platform_label": args.platform, "carrier": "file", "filename": meta["filename"],
        "payload_bytes": meta["payload_bytes"], "payload_sha256": meta["payload_sha256"],
        "created_utc": utc_now(),
    })
    print("[SAFE] Synthetic file only; no Cookie/login persistence / 仅使用合成文件；不保存 Cookie 或登录信息。")

    with SB(browser="chrome", headless=False, uc=True) as sb:
        driver = sb.driver
        driver.get(args.url)
        print("[LOGIN] Please log in manually if needed; the script never reads credentials. / 如需登录请手动完成；脚本不会读取凭据。")
        input("[GATE] When the authorized upload page is ready, press Enter / 授权上传页面就绪后按回车 > ")
        controls = public_dom_probe(driver)
        print_dom_probe(controls)
        if args.probe:
            return 0

        file_input, file_selector = choose_file_input(driver, args.file_selector)
        start = prompt_gate("[MANUAL START] Press Enter immediately before attaching the file / 在附加文件前立即按回车开始人工计时 > ")
        started_utc = utc_now()
        automatic_start = time.perf_counter()
        auto_started_utc = utc_now()
        completed_auto = False
        try:
            file_input.send_keys(str(payload_path))
            print("[UPLOAD] File attached / 文件已附加。")
            if args.submit_selector and args.auto_action:
                driver.find_elements("css selector", args.submit_selector)[0].click()
                print("[UPLOAD] Submit control clicked by approved auto-action / 已按授权自动点击提交控件。")
            elif args.submit_selector:
                input("[MANUAL ACTION] Click the calibrated upload/submit control, then press Enter / 点击已校准的上传/提交控件后按回车 > ")
            else:
                input("[MANUAL ACTION] If required, click Upload/Send, then press Enter / 如页面要求，请点击上传或发送后按回车 > ")
            completed_auto = bool(args.completion_selector) and wait_for_completion(driver, args.completion_selector, args.timeout)
            automatic_end = time.perf_counter()
            auto_ended_utc = utc_now()
            input("[MANUAL END] After the service confirms upload completion, press Enter / 服务确认上传完成后按回车结束人工计时 > ")
            end = time.perf_counter()
            ended_utc = utc_now()
            status = "success" if completed_auto else "manual_complete_without_auto_signal"
            failure_note = ""
        except Exception as exc:
            automatic_end = time.perf_counter()
            auto_ended_utc = utc_now()
            end, ended_utc, status = automatic_end, auto_ended_utc, "upload_error"
            failure_note = f"error_type={type(exc).__name__}"
        audit.append(TrialRecord(
            trial_id=trial_id, carrier="file", platform_label=args.platform, mode="manual+automatic",
            started_utc=started_utc, ended_utc=ended_utc, elapsed_s=max(0.0, end - start),
            status=status, filename=meta["filename"], payload_bytes=meta["payload_bytes"],
            payload_sha256=meta["payload_sha256"], selector_used=file_selector,
            note=(f"completion_signal={'observed' if completed_auto else 'not_observed'}; {failure_note}"),
            manual_started_utc=started_utc, automatic_started_utc=auto_started_utc,
            automatic_ended_utc=auto_ended_utc, manual_ended_utc=ended_utc,
            manual_elapsed_s=max(0.0, end - start),
            automatic_elapsed_s=max(0.0, automatic_end - automatic_start),
        ))
        manifest.append({"record_type": "file_upload_result", "run_id": run_id, "trial_id": trial_id, "status": status, "ended_utc": ended_utc})
        print(f"[DONE] status={status}; manual={end-start:.3f}s; automatic={automatic_end-automatic_start:.3f}s / 状态={status}；人工={end-start:.3f}秒；自动={automatic_end-automatic_start:.3f}秒")
        print(f"[AUDIT] {audit.jsonl_path} / 审计日志：{audit.jsonl_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
