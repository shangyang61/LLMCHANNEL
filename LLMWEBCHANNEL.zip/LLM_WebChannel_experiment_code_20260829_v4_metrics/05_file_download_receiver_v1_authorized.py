#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Authorized file-download measurement with manual and automatic timing.

仅监控指定的空下载目录中新出现的文件。不会读取 Cookie、账号、网页正文，
不会写出完整下载路径；日志只保留文件名、字节数和 SHA-256。
"""
from __future__ import annotations

import argparse
import time
import uuid
from pathlib import Path

from file_transfer_common_v1 import (
    AuditWriter, ManifestWriter, TrialRecord, print_dom_probe, public_dom_probe, prompt_gate,
    safe_id, sha256_file, utc_now,
)


TEMP_SUFFIXES = {".crdownload", ".part", ".tmp"}


def visible_files(directory: Path) -> dict[Path, tuple[int, float]]:
    """Snapshot regular final files / 快照普通最终文件。"""
    out: dict[Path, tuple[int, float]] = {}
    for item in directory.iterdir():
        if item.is_file() and item.suffix.lower() not in TEMP_SUFFIXES:
            stat = item.stat()
            out[item] = (stat.st_size, stat.st_mtime)
    return out


def wait_for_stable_new_file(directory: Path, before: dict[Path, tuple[int, float]], timeout_s: float, stable_s: float) -> Path | None:
    """Detect a new download and wait for unchanged size / 检测新增下载并等待文件大小稳定。"""
    deadline = time.perf_counter() + timeout_s
    candidate: Path | None = None
    candidate_size = -1
    stable_from = 0.0
    while time.perf_counter() < deadline:
        current = visible_files(directory)
        new_items = [p for p in current if p not in before]
        if new_items:
            candidate = max(new_items, key=lambda p: current[p][1])
            size = current[candidate][0]
            now = time.perf_counter()
            if size != candidate_size:
                candidate_size, stable_from = size, now
            elif now - stable_from >= stable_s:
                return candidate
        time.sleep(0.25)
    return None


def configure_download_directory(driver: object, directory: Path) -> None:
    """Request Chrome's per-session download directory / 设置本次 Chrome 会话下载目录。"""
    try:
        driver.execute_cdp_cmd(  # type: ignore[attr-defined]
            "Page.setDownloadBehavior",
            {"behavior": "allow", "downloadPath": str(directory)},
        )
    except Exception as exc:
        print(f"[WARN] Browser download directory was not configured automatically: {exc} / 浏览器下载目录未自动设置，请在 Chrome 中手动选择该目录。")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Authorized file download / 授权文件下载：manual and automatic timing / 人工和自动计时"
    )
    parser.add_argument("--url", required=True, help="Service page URL / 服务页面地址")
    parser.add_argument("--platform", default="service", help="Neutral label only / 仅中性标签")
    parser.add_argument("--download-dir", required=True, help="Empty dedicated directory / 独立且尽量为空的下载目录")
    parser.add_argument("--download-selector", default='', help="Optional CSS selector; otherwise click download manually / 可选下载按钮选择器；否则手动点击")
    parser.add_argument("--expected-sha256", default='', help="Expected file SHA-256 / 预期文件 SHA-256")
    parser.add_argument("--manifest", default='', help="Upload manifest JSONL path / 上传端 manifest JSONL 路径")
    parser.add_argument("--trial-id", default='', help="Trial ID to resolve from manifest / 从 manifest 读取的试验 ID")
    parser.add_argument("--run-id", default='', help="Cross-carrier run ID / 跨载体试验轮次 ID")
    parser.add_argument("--auto-action", action="store_true", help="Allow the script to click --download-selector / 允许脚本点击 --download-selector")
    parser.add_argument("--timeout", type=float, default=120.0)
    parser.add_argument("--stable-seconds", type=float, default=2.0)
    parser.add_argument("--output-dir", default="file_download_results")
    parser.add_argument("--probe", action="store_true", help="Inspect safe control metadata then exit / 仅探测控件后退出")
    parser.add_argument("--authorized", action="store_true", help="Required acknowledgement / 必须确认拥有授权")
    args = parser.parse_args()
    if not args.authorized:
        raise SystemExit("Refusing to run: pass --authorized only for your authorized account/service. / 请仅在授权服务上添加 --authorized。")

    try:
        from seleniumbase import SB  # type: ignore
    except ImportError as exc:
        raise SystemExit("Missing SeleniumBase / 缺少 SeleniumBase：python -m pip install -U seleniumbase") from exc

    download_dir = Path(args.download_dir).expanduser().resolve()
    download_dir.mkdir(parents=True, exist_ok=True)
    run_id = safe_id(args.run_id or f"file-download-{args.platform}-{uuid.uuid4().hex[:8]}")
    trial_id = safe_id(args.trial_id or f"{run_id}-t001")
    audit = AuditWriter(Path(args.output_dir).expanduser().resolve() / run_id)
    result_manifest = ManifestWriter(Path(args.manifest).expanduser().resolve()) if args.manifest else ManifestWriter(audit.output_dir / "file_trial_manifest.jsonl")
    manifest_row: dict[str, object] = {}
    if args.manifest:
        manifest_row = ManifestWriter.resolve(Path(args.manifest).expanduser().resolve(), trial_id)
    expected = (args.expected_sha256.strip() or str(manifest_row.get("payload_sha256", ""))).lower()

    with SB(browser="chrome", headless=False, uc=True) as sb:
        driver = sb.driver
        configure_download_directory(driver, download_dir)
        driver.get(args.url)
        print("[LOGIN] Please log in manually if needed; no credentials or Cookie are read. / 如需登录请手动完成；不读取凭据或 Cookie。")
        input("[GATE] When the authorized download page is ready, press Enter / 授权下载页面就绪后按回车 > ")
        controls = public_dom_probe(driver)
        print_dom_probe(controls)
        if args.probe:
            return 0

        # Baseline immediately before the trial, not before login/page setup.
        before = visible_files(download_dir)
        if before:
            print("[WARN] Download directory is not empty; existing files are ignored. / 下载目录非空；已有文件将被忽略。")

        if args.download_selector:
            start = prompt_gate("[MANUAL START] Press Enter; the script will then click the selected control / 按回车开始人工计时；脚本随后点击指定控件 > ")
        else:
            start = prompt_gate("[MANUAL START] Press Enter, then click Download immediately / 按回车开始人工计时后立即点击下载 > ")
        started_utc = utc_now()
        selector_used = ''
        if args.download_selector:
            selector_used = args.download_selector
            if args.auto_action:
                try:
                    driver.find_elements("css selector", args.download_selector)[0].click()
                    print("[DOWNLOAD] Selector clicked by approved auto-action / 已按授权自动点击下载控件。")
                except Exception as exc:
                    print(f"[WARN] Selector click failed; click manually instead / 选择器点击失败，请手动点击：{exc}")
                    input("[MANUAL ACTION] Click the download control now, then press Enter / 请立即手动点击下载控件后按回车 > ")
            else:
                input("[MANUAL ACTION] Click the calibrated download control, then press Enter / 点击已校准的下载控件后按回车 > ")
        automatic_start = time.perf_counter()
        auto_started_utc = utc_now()
        try:
            file_path = wait_for_stable_new_file(download_dir, before, args.timeout, max(0.5, args.stable_seconds))
            automatic_end = time.perf_counter()
            auto_ended_utc = utc_now()
            if file_path is None:
                input("[MANUAL END] No stable file detected. After completion, press Enter / 未自动检测到稳定文件；完成后按回车 > ")
                status, filename, size, observed = "manual_end_no_file", "", 0, ""
            else:
                input("[MANUAL END] File is stable. Verify any service message, then press Enter / 文件已稳定；核对服务提示后按回车 > ")
                status, filename, size, observed = "download_detected", file_path.name, file_path.stat().st_size, sha256_file(file_path)
            end = time.perf_counter()
            ended_utc = utc_now()
        except Exception as exc:
            automatic_end = time.perf_counter()
            auto_ended_utc = utc_now()
            end, ended_utc = automatic_end, auto_ended_utc
            status, filename, size, observed = f"download_error", "", 0, ""
            print(f"[ERROR] {type(exc).__name__} / 下载错误：{type(exc).__name__}")
        if observed and expected and observed.lower() != expected:
            status = "sha256_mismatch"
        audit.append(TrialRecord(
            trial_id=trial_id, carrier="file", platform_label=args.platform, mode="manual+automatic",
            started_utc=started_utc, ended_utc=ended_utc, elapsed_s=max(0.0, end-start),
            status=status, filename=filename, payload_bytes=size, payload_sha256=expected,
            observed_sha256=observed, selector_used=selector_used,
            note="automatic detection: new file with stable size; no browser content recorded",
            manual_started_utc=started_utc, automatic_started_utc=auto_started_utc,
            automatic_ended_utc=auto_ended_utc, manual_ended_utc=ended_utc,
            manual_elapsed_s=max(0.0, end-start), automatic_elapsed_s=max(0.0, automatic_end-automatic_start),
        ))
        print(f"[DONE] manual={end-start:.3f}s; automatic={automatic_end-automatic_start:.3f}s; status={status} / 人工={end-start:.3f}秒；自动={automatic_end-automatic_start:.3f}秒；状态={status}")
        print(f"[AUDIT] {audit.jsonl_path} / 审计日志：{audit.jsonl_path}")
        result_manifest.append({"record_type": "file_download_result", "run_id": run_id, "trial_id": trial_id, "status": status, "observed_sha256": observed, "ended_utc": ended_utc})
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
