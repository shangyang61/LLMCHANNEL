#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Privacy-preserving control calibration for authorized file experiments.

This is not a session recorder. It records one user-clicked control's structural
fingerprint only: tag/type/role, a CSS path, and hashes of accessibility labels.
It never records page text, typed values, Cookie, account data, URLs, or clicks
on messages. Review the profile before passing its CSS path to an experiment.

这不是会话录制器。它只记录一个由用户手动点击的控件的结构指纹：
tag/type/role、CSS 路径与无障碍标签哈希；不会记录页面文字、输入内容、
Cookie、账号、URL 或消息区域点击。使用前请人工复核生成的 CSS 路径。
"""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


INSTALL_RECORDER_JS = r"""
window.__llmFileCalibration = null;
function llmSafePath(el) {
  const parts=[]; let node=el;
  for(let depth=0; node && node.nodeType===1 && depth<5; depth++, node=node.parentElement) {
    const tag=node.tagName.toLowerCase();
    let index=1, prev=node.previousElementSibling;
    while(prev){if(prev.tagName===node.tagName) index++; prev=prev.previousElementSibling;}
    parts.unshift(`${tag}:nth-of-type(${index})`);
  }
  return parts.join(' > ');
}
document.addEventListener('click', (event) => {
  const el=event.target && event.target.closest && event.target.closest('input,button,[role="button"],a');
  if(!el) return;
  const label=(el.getAttribute('aria-label')||el.getAttribute('title')||'').slice(0,256);
  window.__llmFileCalibration={
    tag:(el.tagName||'').toLowerCase(), type:el.getAttribute('type')||'', role:el.getAttribute('role')||'',
    css_path:llmSafePath(el), label:label, clicked_at:new Date().toISOString()
  };
}, true);
return true;
"""

READ_RECORDER_JS = "return window.__llmFileCalibration || null;"


def label_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Authorized UI calibration / 授权 UI 控件校准")
    parser.add_argument("--url", required=True, help="Authorized service page / 授权服务页面")
    parser.add_argument("--profile", default="file_ui_profile.json", help="Output profile path / 输出配置文件路径")
    parser.add_argument("--authorized", action="store_true", help="Required acknowledgement / 必须确认拥有授权")
    args = parser.parse_args()
    if not args.authorized:
        raise SystemExit("Refusing to run without --authorized / 未提供 --authorized，拒绝运行。")
    try:
        from seleniumbase import SB  # type: ignore
    except ImportError as exc:
        raise SystemExit("Missing SeleniumBase / 缺少 SeleniumBase：python -m pip install -U seleniumbase") from exc

    with SB(browser="chrome", headless=False, uc=True) as sb:
        driver = sb.driver
        driver.get(args.url)
        print("[LOGIN] Log in manually if needed; credentials are never read. / 如需登录请手动完成；不会读取凭据。")
        input("[GATE] When the authorized page is ready, press Enter / 授权页面就绪后按回车 > ")
        driver.execute_script(INSTALL_RECORDER_JS)
        input("[CALIBRATE] Click exactly one upload/download control in the browser, then return here and press Enter / 在浏览器中只点击一个上传或下载控件，再回到这里按回车 > ")
        item = driver.execute_script(READ_RECORDER_JS)
        if not isinstance(item, dict):
            raise SystemExit("No eligible control click observed / 未检测到合格的控件点击。")
        raw_label = str(item.pop("label", ""))
        item["label_sha256"] = label_hash(raw_label) if raw_label else ""
        item["captured_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
        item["privacy_note"] = "No page text, typed values, cookies, account data, or URL were recorded."
        output = Path(args.profile).expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(item, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[SAVED] Calibrated CSS path: {item['css_path']} / 已保存校准 CSS 路径：{item['css_path']}")
        print(f"[PROFILE] {output} / 配置文件：{output}")
        print("[REVIEW] Review this path manually before using it with --file-selector or --download-selector. / 请人工复核后再传给上传或下载脚本。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
