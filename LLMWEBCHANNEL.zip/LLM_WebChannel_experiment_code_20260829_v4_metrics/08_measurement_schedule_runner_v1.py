#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Schedule stability, persistence, and condition measurements.

该程序只负责生成试验计划、调用你指定的本地测试命令并记录退出状态；
不擅自更改网络、浏览器负载或系统配置。条件标签必须如实反映由研究者
在外部建立的实验条件。
"""
from __future__ import annotations

import argparse
import json
import subprocess
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def main() -> int:
    parser = argparse.ArgumentParser(description="Measurement schedule runner / 稳定性、持久性与条件测试调度器")
    parser.add_argument("--kind", choices=("stability", "persistence", "condition"), required=True)
    parser.add_argument("--platform", required=True)
    parser.add_argument("--carrier", choices=("text", "file", "url"), required=True)
    parser.add_argument("--rounds", type=int, default=1, help="Rounds per condition / 每个条件的轮数")
    parser.add_argument("--conditions", default="baseline", help="Comma-separated labels / 逗号分隔条件标签")
    parser.add_argument("--persistence-delays-s", default="300", help="Persistence delays in seconds / 持久性等待秒数")
    parser.add_argument("--command-template", default="", help="Local command with {trial_id},{condition},{round},{delay_s} / 本地命令模板")
    parser.add_argument("--output-dir", default="measurement_schedule_results")
    parser.add_argument("--dry-run", action="store_true", help="Write plan only / 只写计划，不执行命令")
    args = parser.parse_args()
    if args.rounds < 1:
        raise SystemExit("--rounds must be >= 1 / --rounds 必须至少为 1")
    if not args.dry_run and not args.command_template:
        raise SystemExit("A local --command-template is required unless --dry-run / 除非 --dry-run，否则必须提供本地 --command-template。")

    root = Path(args.output_dir).expanduser().resolve() / f"{args.kind}-{uuid.uuid4().hex[:8]}"
    root.mkdir(parents=True, exist_ok=True)
    audit_path = root / "schedule_audit.jsonl"
    conditions = [x.strip() for x in args.conditions.split(",") if x.strip()]
    delays = [int(x.strip()) for x in args.persistence_delays_s.split(",") if x.strip()] if args.kind == "persistence" else [0]
    plan = []
    sequence = 0
    for condition in conditions:
        for delay_s in delays:
            for round_no in range(1, args.rounds + 1):
                sequence += 1
                plan.append({"sequence": sequence, "trial_id": f"{args.kind}-{sequence:04d}", "condition": condition, "round": round_no, "delay_s": delay_s})
    (root / "schedule_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[PLAN] {len(plan)} trials written / 已写入 {len(plan)} 个试验：{root / 'schedule_plan.json'}")

    with audit_path.open("a", encoding="utf-8") as audit:
        for item in plan:
            if item["delay_s"]:
                print(f"[WAIT] persistence delay={item['delay_s']}s / 持久性等待={item['delay_s']}秒")
                time.sleep(item["delay_s"])
            record = {"started_utc": now(), "kind": args.kind, "platform": args.platform, "carrier": args.carrier, **item}
            if args.dry_run:
                record.update({"status": "dry_run", "ended_utc": now(), "returncode": 0})
            else:
                command = args.command_template.format(**item)
                print(f"[RUN] trial={item['trial_id']} condition={item['condition']} / 执行试验={item['trial_id']}，条件={item['condition']}")
                completed = subprocess.run(command, shell=True, check=False)
                record.update({"status": "completed" if completed.returncode == 0 else "command_failed", "ended_utc": now(), "returncode": completed.returncode})
            audit.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
            audit.flush()
    print(f"[DONE] Audit written / 审计已写入：{audit_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
