#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compare sender and recovered content without retaining either plaintext.

比较发送内容与提取内容。报告仅保存长度、哈希、是否相同和尾随空格情况，
不把两侧的原文写入日志或报告。
"""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def read_value(path: str, inline: str) -> bytes:
    if path:
        return Path(path).expanduser().read_bytes()
    return inline.encode("utf-8")


def normalize_one_trailing_space(value: bytes) -> bytes:
    """Documented text normalizer / 仅移除一个文档化的尾随 ASCII 空格。"""
    return value[:-1] if value.endswith(b" ") else value


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Content comparison / 内容一致性比较")
    sent = parser.add_mutually_exclusive_group(required=True)
    received = parser.add_mutually_exclusive_group(required=True)
    sent.add_argument("--sent-file", default="", help="Sender content file / 发送内容文件")
    sent.add_argument("--sent-text", default="", help="Sender text (avoid shell history) / 发送文本（避免写入终端历史）")
    received.add_argument("--recovered-file", default="", help="Recovered content file / 提取内容文件")
    received.add_argument("--recovered-text", default="", help="Recovered text (avoid shell history) / 提取文本（避免写入终端历史）")
    parser.add_argument("--binary", action="store_true", help="Disable text normalizer / 禁用文本正规化")
    parser.add_argument("--report", default="", help="Optional metadata-only JSON report / 可选仅元数据 JSON 报告")
    args = parser.parse_args()

    sender = read_value(args.sent_file, args.sent_text)
    recovered = read_value(args.recovered_file, args.recovered_text)
    normalized_sender = sender if args.binary else normalize_one_trailing_space(sender)
    normalized_recovered = recovered if args.binary else normalize_one_trailing_space(recovered)
    report = {
        "compared_utc": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
        "mode": "binary" if args.binary else "text_single_trailing_ascii_space_normalizer",
        "sender_bytes": len(sender), "recovered_bytes": len(recovered),
        "sender_sha256": digest(sender), "recovered_sha256": digest(recovered),
        "normalized_sender_bytes": len(normalized_sender), "normalized_recovered_bytes": len(normalized_recovered),
        "normalized_sender_sha256": digest(normalized_sender),
        "normalized_recovered_sha256": digest(normalized_recovered),
        "raw_equal": sender == recovered,
        "normalized_content_consistent": normalized_sender == normalized_recovered,
        "recovered_has_one_trailing_ascii_space": recovered.endswith(b" ") and not recovered.endswith(b"  "),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if args.report:
        destination = Path(args.report).expanduser().resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[REPORT] Metadata-only report saved / 已保存仅元数据报告：{destination}")
    return 0 if report["normalized_content_consistent"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
